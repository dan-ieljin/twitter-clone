let hours_worked = 16
